/*
   Copyright 2023 Stefano Carpin

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include <rclcpp/rclcpp.hpp> 
#include <navigation/navigation.hpp>
#include <iostream>
#include <sensor_msgs/msg/laser_scan.hpp>

float points[17][2] = {{0.6, -1.8}, {1.6, -1.6}, {1.8, -0.8}, {1.8, 0.8}, {1.5, 1.5}, {0.5, 1.75}, {-0.5, 1.75}, {-1.5, 1.5}, {-1.8, 0.8}, {-0.5, 0.5}, {0.5, 0.5}, {0.5, -0.5}, {-0.5, -0.5}, {-1.5, 1.5}, {-1.8, 0.8}, {-1.5, 1.5}, {-1.6, -1.6}};

std::vector<float>::const_iterator minNum;


int main(int argc,char **argv) {

	rclcpp::init(argc,argv); // initialize ROS 
	Navigator navigator(true,false); // create node with debug info but not verbose

	// first: it is mandatory to initialize the pose of the robot
	geometry_msgs::msg::Pose::SharedPtr init = std::make_shared<geometry_msgs::msg::Pose>();
	init->position.y = -2;
	init->position.x = -0.5;
	init->orientation.w = 1;
	navigator.SetInitialPose(init);
	// wait for navigation stack to become operationale
	navigator.WaitUntilNav2Active();
	// spin in place of 90 degrees (default parameter)
	navigator.Spin();
	while ( ! navigator.IsTaskComplete() ) {
		// busy waiting for task to be completed
	}

	geometry_msgs::msg::Pose::SharedPtr goal_pos = std::make_shared<geometry_msgs::msg::Pose>();

	for(int i = 0; i < 17; i++) {
		while ( ! navigator.IsTaskComplete() ) {
		}
		
		goal_pos->position.x = points[i][0];
		goal_pos->position.y = points[i][1];
		goal_pos->orientation.w = 1;
		
		// move to new pose
		navigator.GoToPose(goal_pos);
	}
	// complete here....

	rclcpp::shutdown(); // shutdown ROS
	return 0;
}
